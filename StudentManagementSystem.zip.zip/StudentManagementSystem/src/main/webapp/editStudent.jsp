
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8" %>
<%@ page import="com.sms.model.Student" %>

<%!
    private String escapeHtml(String value) {
        if (value == null) {
            return "";
        }

        return value.replace("&", "&amp;")
                    .replace("<", "&lt;")
                    .replace(">", "&gt;")
                    .replace("\"", "&quot;")
                    .replace("'", "&#39;");
    }
%>

<%
    Student student = (Student) request.getAttribute("student");

    if (student == null) {
        response.sendRedirect(request.getContextPath() + "/viewStudents");
        return;
    }
%>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Edit Student</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f0f4f8;
            padding: 30px;
        }

        .container {
            max-width: 450px;
            margin: auto;
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 4px 12px #0002;
        }

        h2 {
            text-align: center;
            color: #234e70;
        }

        label {
            display: block;
            margin-top: 15px;
            font-weight: bold;
        }

        input {
            width: 100%;
            box-sizing: border-box;
            padding: 10px;
            margin-top: 6px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        button {
            width: 100%;
            padding: 12px;
            margin-top: 22px;
            background: #198754;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }

        button:hover {
            background: #146c43;
        }

        a {
            display: block;
            text-align: center;
            margin-top: 15px;
            color: #234e70;
            text-decoration: none;
        }
    </style>
</head>

<body>
    <div class="container">

        <h2>Edit Student Details</h2>

        <form action="<%= request.getContextPath() %>/updateStudent"
              method="post">

            <input type="hidden" name="id"
                   value="<%= student.getId() %>">

            <label for="name">Name</label>
            <input type="text" id="name" name="name"
                   value="<%= escapeHtml(student.getName()) %>"
                   required>

            <label for="email">Email</label>
            <input type="email" id="email" name="email"
                   value="<%= escapeHtml(student.getEmail()) %>"
                   required>

            <label for="phone">Phone</label>
            <input type="text" id="phone" name="phone"
                   value="<%= escapeHtml(student.getPhone()) %>">

            <label for="course">Course</label>
            <input type="text" id="course" name="course"
                   value="<%= escapeHtml(student.getCourse()) %>"
                   required>

            <button type="submit">Update Student</button>
        </form>

        <a href="<%= request.getContextPath() %>/viewStudents">
            Back to Student List
        </a>

        <a href="<%= request.getContextPath() %>/index.html">
            Home
        </a>

    </div>
</body>
</html>


package com.sms.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sms.dao.StudentDAO;
import com.sms.model.Student;

@WebServlet("/viewStudents")
public class ViewStudentsServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    private StudentDAO studentDAO = new StudentDAO();

    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");

        List<Student> students = studentDAO.getAllStudents();

        PrintWriter out = response.getWriter();

        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<head>");
        out.println("<meta charset='UTF-8'>");
        out.println("<meta name='viewport' content='width=device-width, initial-scale=1.0'>");
        out.println("<title>View Students</title>");

        out.println("<style>");

        out.println("body{font-family:Arial,sans-serif;"
                + "background:#f0f4f8;padding:30px;margin:0}");

        out.println("h2{text-align:center;color:#234e70}");

        out.println(".top-actions{text-align:center;margin:20px 0}");

        out.println(".btn{display:inline-block;padding:10px 16px;"
                + "border-radius:5px;text-decoration:none;color:white;"
                + "margin:5px}");

        out.println(".search{background:#0d6efd}");
        out.println(".search:hover{background:#0b5ed7}");

        out.println(".add{background:#198754}");
        out.println(".add:hover{background:#146c43}");

        out.println(".logout{background:#dc3545}");
        out.println(".logout:hover{background:#b02a37}");

        out.println("table{width:100%;border-collapse:collapse;"
                + "background:white}");

        out.println("th,td{padding:12px;border:1px solid #ddd;"
                + "text-align:left}");

        out.println("th{background:#234e70;color:white}");

        out.println(".edit{display:inline-block;background:#198754;"
                + "color:white;padding:8px 12px;border-radius:5px;"
                + "text-decoration:none;margin:3px}");

        out.println(".edit:hover{background:#146c43}");

        out.println(".delete{display:inline-block;background:#dc3545;"
                + "color:white;padding:8px 12px;border-radius:5px;"
                + "text-decoration:none;margin:3px}");

        out.println(".delete:hover{background:#b02a37}");

        out.println(".message{font-weight:bold;text-align:center;"
                + "color:green}");

        out.println(".error{font-weight:bold;text-align:center;color:red}");

        out.println(".table-container{overflow-x:auto}");

        out.println("</style>");
        out.println("</head>");
        out.println("<body>");

        out.println("<h2>All Students</h2>");

        // Search, Add Student and Logout buttons
        out.println("<div class='top-actions'>");

        out.println("<a class='btn search' href='searchStudent'>"
                + "Search Students</a>");

        out.println("<a class='btn add' href='addStudent.html'>"
                + "Add Student</a>");

        out.println("<a class='btn logout' href='logout' "
                + "onclick=\"return confirm('Are you sure you want to logout?');\">"
                + "Logout</a>");

        out.println("</div>");

        // Status messages
        String status = request.getParameter("status");

        if ("updated".equals(status)) {
            out.println("<p class='message'>"
                    + "Student updated successfully!</p>");
        } else if ("deleted".equals(status)) {
            out.println("<p class='message'>"
                    + "Student deleted successfully!</p>");
        } else if ("error".equals(status)) {
            out.println("<p class='error'>"
                    + "Operation failed. Please try again.</p>");
        }

        // Student table
        out.println("<div class='table-container'>");
        out.println("<table>");

        out.println("<tr>");
        out.println("<th>ID</th>");
        out.println("<th>Name</th>");
        out.println("<th>Email</th>");
        out.println("<th>Phone</th>");
        out.println("<th>Course</th>");
        out.println("<th>Action</th>");
        out.println("</tr>");

        for (Student s : students) {

            out.println("<tr>");

            out.println("<td>" + s.getId() + "</td>");
            out.println("<td>" + escapeHtml(s.getName()) + "</td>");
            out.println("<td>" + escapeHtml(s.getEmail()) + "</td>");
            out.println("<td>" + escapeHtml(s.getPhone()) + "</td>");
            out.println("<td>" + escapeHtml(s.getCourse()) + "</td>");

            // Edit and Delete buttons
            out.println("<td>");

            out.println("<a class='edit' href='editStudent?id="
                    + s.getId() + "'>Edit / Update</a>");

            out.println("<a class='delete' href='deleteStudent?id="
                    + s.getId()
                    + "' onclick=\"return confirm('Are you sure you want to delete this student?');\">"
                    + "Delete</a>");

            out.println("</td>");
            out.println("</tr>");
        }

        out.println("</table>");
        out.println("</div>");

        out.println("<a href='adminDashboard'>Home</a>");

        out.println("</body>");
        out.println("</html>");
    }

    private String escapeHtml(String value) {

        if (value == null) {
            return "";
        }

        return value.replace("&", "&amp;")
                    .replace("<", "&lt;")
                    .replace(">", "&gt;")
                    .replace("\"", "&quot;")
                    .replace("'", "&#39;");
    }
}

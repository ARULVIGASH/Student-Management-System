
package com.sms.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sms.dao.AdminDAO;
import com.sms.model.Admin;
import com.sms.util.PasswordUtil;

@WebServlet("/adminRegister")
public class AdminRegisterServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    private AdminDAO adminDAO = new AdminDAO();

    @Override
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        if (name == null || email == null || password == null
                || name.trim().isEmpty()
                || email.trim().isEmpty()
                || password.length() < 8) {

            response.sendRedirect("register.html?status=invalid");
            return;
        }

        name = name.trim();
        email = email.trim();

        // Check whether this email is already registered
        if (adminDAO.getAdminByEmail(email) != null) {
            response.sendRedirect("register.html?status=exists");
            return;
        }

        String passwordHash = PasswordUtil.hashPassword(password);

        Admin admin = new Admin(name, email, passwordHash);

        boolean registered = adminDAO.registerAdmin(admin);

        if (registered) {
            response.sendRedirect("login.html?status=registered");
        } else {
            response.sendRedirect("register.html?status=error");
        }
    }
}

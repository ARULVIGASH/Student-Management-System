
package com.sms.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import com.sms.dao.StudentDAO;
import com.sms.model.Student;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/searchStudent")
public class SearchStudentServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    private StudentDAO studentDAO = new StudentDAO();

    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        String keyword = request.getParameter("keyword");

        response.setContentType("text/html;charset=UTF-8");

        PrintWriter out = response.getWriter();

        out.println("<html><head><title>Search Students</title>");
        out.println("<style>");
        out.println("body{font-family:Arial;background:#f4f7f6;"
                + "padding:30px}");
        out.println("h2{text-align:center;color:#198754}");
        out.println("form{text-align:center;margin:25px}");
        out.println("input{padding:10px;width:250px}");
        out.println("button{padding:10px;background:#198754;"
                + "color:white;border:0;cursor:pointer}");
        out.println("table{width:100%;border-collapse:collapse;"
                + "background:white}");
        out.println("th,td{padding:12px;border:1px solid #ddd;"
                + "text-align:center}");
        out.println("th{background:#198754;color:white}");
        out.println("a{color:#198754}");
        out.println("</style></head><body>");

        out.println("<h2>Search Students</h2>");

        out.println("<form action='searchStudent' method='get'>");
        out.println("<input type='text' name='keyword' "
                + "placeholder='Enter student ID or name' required>");
        out.println("<button type='submit'>Search</button>");
        out.println("</form>");

        if (keyword != null && !keyword.trim().isEmpty()) {

            List<Student> students =
                    studentDAO.searchStudents(keyword.trim());

            if (students.isEmpty()) {
                out.println("<p style='text-align:center;color:red'>"
                        + "No students found.</p>");
            } else {

                out.println("<table>");
                out.println("<tr><th>ID</th><th>Name</th>"
                        + "<th>Email</th><th>Phone</th>"
                        + "<th>Course</th></tr>");

                for (Student s : students) {
                    out.println("<tr>");
                    out.println("<td>" + s.getId() + "</td>");
                    out.println("<td>" + s.getName() + "</td>");
                    out.println("<td>" + s.getEmail() + "</td>");
                    out.println("<td>" + s.getPhone() + "</td>");
                    out.println("<td>" + s.getCourse() + "</td>");
                    out.println("</tr>");
                }

                out.println("</table>");
            }
        }

        out.println("<p style='text-align:center;margin-top:25px'>");
        out.println("<a href='viewStudents'>Back to View Students</a>");
        out.println("</p>");

        out.println("</body></html>");
    }
}

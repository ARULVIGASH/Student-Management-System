
package com.sms.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sms.dao.StudentDAO;

@WebServlet("/deleteStudent")
public class DeleteStudentServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;
    private StudentDAO studentDAO = new StudentDAO();

    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        try {
            int id = Integer.parseInt(request.getParameter("id"));

            boolean deleted = studentDAO.deleteStudent(id);

            if (deleted) {
                response.sendRedirect(
                    request.getContextPath()
                    + "/viewStudents?status=deleted"
                );
            } else {
                response.sendRedirect(
                    request.getContextPath()
                    + "/viewStudents?status=error"
                );
            }

        } catch (NumberFormatException e) {
            response.sendRedirect(
                request.getContextPath()
                + "/viewStudents?status=error"
            );
        }
    }
}


package com.sms.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.sms.dao.StudentDAO;

@WebServlet("/adminDashboard")
public class AdminDashboardServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    private StudentDAO studentDAO = new StudentDAO();

    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);

        // Only logged-in admins can open the dashboard
        if (session == null
                || session.getAttribute("adminId") == null) {

            response.sendRedirect(
                    request.getContextPath() + "/login.html");
            return;
        }

        String adminName =
                (String) session.getAttribute("adminName");

        if (adminName == null || adminName.trim().isEmpty()) {
            adminName = "Administrator";
        }

        int totalStudents = studentDAO.getTotalStudents();

        response.setContentType("text/html;charset=UTF-8");

        PrintWriter out = response.getWriter();

        String contextPath = request.getContextPath();

        out.println("<!DOCTYPE html>");
        out.println("<html lang='en'>");
        out.println("<head>");
        out.println("<meta charset='UTF-8'>");
        out.println("<meta name='viewport' "
                + "content='width=device-width, initial-scale=1.0'>");
        out.println("<title>Admin Dashboard</title>");

        out.println("<style>");

        out.println("*{box-sizing:border-box}");

        out.println("body{margin:0;font-family:Arial,sans-serif;"
                + "background:#f3f6fb;color:#263445}");

        out.println(".header{background:#17365d;color:white;"
                + "padding:22px 35px;display:flex;"
                + "justify-content:space-between;align-items:center;"
                + "gap:15px;flex-wrap:wrap}");

        out.println(".header h1{margin:0;font-size:24px}");

        out.println(".header p{margin:7px 0 0;color:#d7e5f5}");

        out.println(".logout{background:#dc3545;color:white;"
                + "padding:10px 16px;text-decoration:none;"
                + "border-radius:6px;font-weight:bold}");

        out.println(".logout:hover{background:#b02a37}");

        out.println(".container{max-width:1150px;margin:35px auto;"
                + "padding:0 22px}");

        out.println(".welcome{margin-bottom:25px}");

        out.println(".welcome h2{margin-bottom:8px;color:#17365d}");

        out.println(".welcome p{color:#64748b}");

        out.println(".stats{display:grid;"
                + "grid-template-columns:repeat(auto-fit,minmax(220px,1fr));"
                + "gap:20px;margin-bottom:30px}");

        out.println(".card{background:white;padding:25px;"
                + "border-radius:12px;"
                + "box-shadow:0 4px 14px rgba(0,0,0,0.06);"
                + "border:1px solid #e6ebf2}");

        out.println(".card h3{margin:0 0 15px;color:#526174;"
                + "font-size:15px}");

        out.println(".count{font-size:36px;font-weight:bold;"
                + "color:#2457a7}");

        out.println(".actions{display:grid;"
                + "grid-template-columns:repeat(auto-fit,minmax(220px,1fr));"
                + "gap:20px}");

        out.println(".action-card{display:block;background:white;"
                + "padding:25px;border-radius:12px;"
                + "text-decoration:none;color:#263445;"
                + "border:1px solid #e6ebf2;"
                + "box-shadow:0 4px 14px rgba(0,0,0,0.05);"
                + "transition:transform 0.2s,box-shadow 0.2s}");

        out.println(".action-card:hover{transform:translateY(-4px);"
                + "box-shadow:0 8px 20px rgba(0,0,0,0.10)}");

        out.println(".action-card h3{margin:0 0 10px;color:#17365d}");

        out.println(".action-card p{margin:0;color:#64748b;"
                + "line-height:1.5}");

        out.println(".icon{font-size:28px;margin-bottom:12px}");

        out.println(".footer{text-align:center;padding:25px;"
                + "color:#64748b;font-size:13px}");

        out.println("@media(max-width:600px){"
                + ".header{padding:20px}.container{margin:25px auto}"
                + ".header h1{font-size:20px}}");

        out.println("</style>");
        out.println("</head>");

        out.println("<body>");

        // Header
        out.println("<header class='header'>");

        out.println("<div>");
        out.println("<h1>Student Management System</h1>");
        out.println("<p>Administrator Dashboard</p>");
        out.println("</div>");

        out.println("<a class='logout' href='" + contextPath
                + "/logout' "
                + "onclick=\"return confirm('Are you sure you want to logout?');\">"
                + "Logout</a>");

        out.println("</header>");

        out.println("<main class='container'>");

        // Welcome message
        out.println("<section class='welcome'>");
        out.println("<h2>Welcome, "
                + escapeHtml(adminName) + "!</h2>");
        out.println("<p>Manage your student records from one place.</p>");
        out.println("</section>");

        // Total students card
        out.println("<section class='stats'>");

        out.println("<div class='card'>");
        out.println("<h3>Total Students</h3>");
        out.println("<div class='count'>" + totalStudents + "</div>");
        out.println("<p>Students registered in your database</p>");
        out.println("</div>");

        out.println("</section>");

        // Navigation cards
        out.println("<h2>Student Management</h2>");

        out.println("<section class='actions'>");

        out.println("<a class='action-card' href='" + contextPath
                + "/addStudent.html'>");

        out.println("<div class='icon'>&#10133;</div>");
        out.println("<h3>Add Student</h3>");
        out.println("<p>Register a new student with personal "
                + "and course details.</p>");
        out.println("</a>");

        out.println("<a class='action-card' href='" + contextPath
                + "/viewStudents'>");

        out.println("<div class='icon'>&#128101;</div>");
        out.println("<h3>View Students</h3>");
        out.println("<p>View, edit, update, and delete student records.</p>");
        out.println("</a>");

        out.println("<a class='action-card' href='" + contextPath
                + "/searchStudent'>");

        out.println("<div class='icon'>&#128269;</div>");
        out.println("<h3>Search Students</h3>");
        out.println("<p>Quickly find a student in your records.</p>");
        out.println("</a>");

        out.println("</section>");
        out.println("</main>");

        out.println("<footer class='footer'>");
        out.println("Student Management System &copy; 2026");
        out.println("</footer>");

        out.println("</body>");
        out.println("</html>");
    }

    private String escapeHtml(String value) {

        if (value == null) {
            return "";
        }

        return value.replace("&", "&amp;")
                    .replace("<", "&lt;")
                    .replace(">", "&gt;")
                    .replace("\"", "&quot;")
                    .replace("'", "&#39;");
    }
}

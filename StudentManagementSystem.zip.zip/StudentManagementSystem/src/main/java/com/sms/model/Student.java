
package com.sms.model;

public class Student {

    private int id;
    private String name;
    private String email;
    private String phone;
    private String course;

    // Default constructor
    public Student() {
    }

    // Constructor without ID
    public Student(String name, String email,
                   String phone, String course) {
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.course = course;
    }

    // Getters and setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }
}


package com.sms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.sms.model.Student;
import com.sms.util.DBConnection;

public class StudentDAO {

    // 1. Add a student
    public boolean addStudent(Student student) {

        String sql = "INSERT INTO students "
                + "(name, email, phone, course) "
                + "VALUES (?, ?, ?, ?)";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, student.getName());
            ps.setString(2, student.getEmail());
            ps.setString(3, student.getPhone());
            ps.setString(4, student.getCourse());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // 2. View all students
    public List<Student> getAllStudents() {

        List<Student> students = new ArrayList<>();

        String sql = "SELECT * FROM students";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {

                Student student = new Student();

                student.setId(rs.getInt("id"));
                student.setName(rs.getString("name"));
                student.setEmail(rs.getString("email"));
                student.setPhone(rs.getString("phone"));
                student.setCourse(rs.getString("course"));

                students.add(student);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return students;
    }

    // 3. Get a student by ID
    public Student getStudentById(int id) {

        String sql = "SELECT * FROM students WHERE id = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {

                    Student student = new Student();

                    student.setId(rs.getInt("id"));
                    student.setName(rs.getString("name"));
                    student.setEmail(rs.getString("email"));
                    student.setPhone(rs.getString("phone"));
                    student.setCourse(rs.getString("course"));

                    return student;
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }

    // 4. Update a student
    public boolean updateStudent(Student student) {

        String sql = "UPDATE students SET name = ?, email = ?, "
                + "phone = ?, course = ? WHERE id = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, student.getName());
            ps.setString(2, student.getEmail());
            ps.setString(3, student.getPhone());
            ps.setString(4, student.getCourse());
            ps.setInt(5, student.getId());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
   
    public boolean deleteStudent(int id) {
        String sql = "DELETE FROM students WHERE id = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }
    

    // 6. Search students by ID or name

public List<Student> searchStudents(String keyword) {

    List<Student> students = new java.util.ArrayList<>();

    String sql = "SELECT * FROM students "
            + "WHERE name LIKE ? "
            + "OR email LIKE ? "
            + "OR phone LIKE ? "
            + "OR course LIKE ?";

    try (java.sql.Connection con =
                 com.sms.util.DBConnection.getConnection();
         java.sql.PreparedStatement ps =
                 con.prepareStatement(sql)) {

        String searchValue = "%" + keyword.trim() + "%";

        ps.setString(1, searchValue);
        ps.setString(2, searchValue);
        ps.setString(3, searchValue);
        ps.setString(4, searchValue);

        try (java.sql.ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {

                Student student = new Student();

                student.setId(rs.getInt("id"));
                student.setName(rs.getString("name"));
                student.setEmail(rs.getString("email"));
                student.setPhone(rs.getString("phone"));
                student.setCourse(rs.getString("course"));

                students.add(student);
            }
        }

    } catch (java.sql.SQLException e) {
        e.printStackTrace();
    }

    return students;
}


public int getTotalStudents() {

    String sql = "SELECT COUNT(*) FROM students";

    try (java.sql.Connection con =
                 com.sms.util.DBConnection.getConnection();
         java.sql.PreparedStatement ps =
                 con.prepareStatement(sql);
         java.sql.ResultSet rs = ps.executeQuery()) {

        if (rs.next()) {
            return rs.getInt(1);
        }

    } catch (java.sql.SQLException e) {
        e.printStackTrace();
    }

    return 0;
}


    
}
